package TheNeighborRater;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheNeighborRaterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheNeighborRaterApplication.class, args);
	}
}
